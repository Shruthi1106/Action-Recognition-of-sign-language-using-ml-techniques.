# Importing the Libraries Required

import os
import string

# Creating the directory Structure

if not os.path.exists("dataSet7"):
    os.makedirs("dataSet7")

if not os.path.exists("dataSet7/trainingData"):
    os.makedirs("dataSet7/trainingData")

if not os.path.exists("dataSet7/testingData"):
    os.makedirs("dataSet7/testingData")

# Making folders from 0 to Z in the training and testing data folders respectively

for i in range(0,10):  # Range from 0 to Z (inclusive)
    if not os.path.exists("dataSet7/trainingData/" + str(i)):
        os.makedirs("dataSet7/trainingData/" + str(i))

    if not os.path.exists("dataSet7/testingData/" + str(i)):
        os.makedirs("dataSet7/testingData/" + str(i))

# Making Folders from A to Z in the training and testing data folders respectively

for i in string.ascii_uppercase:
    if not os.path.exists("dataSet7/trainingData/" + i):
        os.makedirs("dataSet7/trainingData/" + i)
    
    if not os.path.exists("dataSet7/testingData/" + i):
        os.makedirs("dataSet7/testingData/" + i)
