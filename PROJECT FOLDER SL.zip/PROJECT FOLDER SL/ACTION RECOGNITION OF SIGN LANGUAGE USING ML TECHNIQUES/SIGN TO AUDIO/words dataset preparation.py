import cv2
import numpy as np
import os

# Function to create directory if it doesn't exist
def create_directory(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

# Creating and Collecting Training Data
mode = 'trainingData'
base_directory = 'D:/Sign-Language-To-Text-Conversion-main 1/Sign-Language-To-Text-Conversion-main/dataSetpt/'
directory = os.path.join(base_directory, mode)

# Create directories for each class
classes = ['remember', 'love' ,'like']
for class_name in classes:
    class_directory = os.path.join(directory, class_name)
    create_directory(class_directory)

minValue = 70

capture = cv2.VideoCapture(0)
interrupt = -1

while True:
    _, frame = capture.read()

    # Simulating mirror Image
    frame = cv2.flip(frame, 1)

    # Getting count of existing images
    count = {}
    for class_name in classes:
        count[class_name] = len(os.listdir(os.path.join(directory, class_name)))

    # Printing the count of each class on the screen
    for i, class_name in enumerate(classes):
        cv2.putText(frame, f"{class_name.upper()} : {count[class_name]}", (10, 50 + i * 20), cv2.FONT_HERSHEY_PLAIN, 1, (0,255,255), 1)

    # Coordinates of the ROI
    x1 = int(0.5 * frame.shape[1])
    y1 = 10
    x2 = frame.shape[1] - 10
    y2 = int(0.5 * frame.shape[1])

    # Drawing the ROI
    cv2.rectangle(frame, (x1-1, y1-1), (x2+1, y2+1), (255,0,0) ,1)

    # Extracting the ROI
    roi = frame[y1:y2, x1:x2]

    cv2.imshow("Frame", frame)
    
    # Image Processing
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 2)
    th3 = cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
    ret, test_image = cv2.threshold(th3, minValue, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
    
    # Output Image after the Image Processing that is used for data collection
    test_image = cv2.resize(test_image, (300,300))
    cv2.imshow("test", test_image)

    # Data Collection
    interrupt = cv2.waitKey(10)
    for i, class_name in enumerate(classes):
        if interrupt & 0xFF == ord(class_name[0]):
            cv2.imwrite(os.path.join(directory, class_name, f"{count[class_name]}.jpg"), roi)
            break
    if interrupt & 0xFF == 27:  # esc key
        break

capture.release()
cv2.destroyAllWindows()
